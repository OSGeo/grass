## DESCRIPTION

The tool *r.plus.example* adds two raster maps.

## NOTES

## EXAMPLES

```sh
r.plus.example
```

## SEE ALSO

*[g.region](g.region.md)*

## AUTHOR

Vaclav Petras, NCSU GeoForAll Lab
